// Handle login form submission
document.getElementById('login-form').addEventListener('submit', function(e) {
    e.preventDefault();
    let email = document.getElementById('login-email').value;
    let password = document.getElementById('login-password').value;
    
    console.log('Login Attempt:', email, password);
    // Add login logic here (e.g., API call)
});

// Handle sign-up form submission
document.getElementById('signup-form').addEventListener('submit', function(e) {
    e.preventDefault();
    let email = document.getElementById('signup-email').value;
    let password = document.getElementById('signup-password').value;
    
    console.log('Sign Up Attempt:', email, password);
    // Add sign-up logic here (e.g., API call)
});

// Handle forgot password click
document.getElementById('forgot-password').addEventListener('click', function() {
    alert('Redirecting to forgot password page...');
    // Redirect to forgot password page or open modal
});

// Handle account activation button
document.getElementById('activate-account').addEventListener('click', function() {
    alert('Activating account...');
    // Add account activation logic here (e.g., API call)
});
